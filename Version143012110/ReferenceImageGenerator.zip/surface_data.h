//---------------------------------------------------------------------------
#ifndef surface_dataH
#define surface_dataH
//---------------------------------------------------------------------------
#include "types.h"
//---------------------------------------------------------------------------

namespace nbs {
	
struct Surface_data
{
	nbs::uint8* ptr;
	nbs::uint32 bit_count;
	nbs::uint32 width;
	nbs::uint32 height;
	nbs::uint32 pitch;
};

}; // end namespace nbs

//---------------------------------------------------------------------------
#endif