//---------------------------------------------------------------------------
#ifndef typesH
#define typesH
//---------------------------------------------------------------------------
#include "..\import\loki\static_check.h"
#include <limits>
//---------------------------------------------------------------------------

namespace nbs {

/*
Quick conversion chart:
BYTE = uint8
WORD = uint16
DWORD = uint32
LONGLONG = sint64
ULONGLONG = uint64
LARGE_INTEGER = Large_int
*/

typedef unsigned char      uint8;   // 8 -bit unsigned
typedef char               sint8;   // 8 -bit   signed
typedef char               SBYTE;   // 8 -bit   signed 

typedef unsigned short int uint16;  // 16-bit unsigned
typedef short int          sint16;  // 16-bit   signed
typedef short int          SWORD;   // 16-bit   signed

typedef unsigned long int  uint32;  // 32-bit unsigned
typedef long int           sint32;  // 32-bit   signed
typedef long int           SDWORD;  // 32-bit   signed

typedef unsigned __int64   uint64;  // 64-bit   unsigned
typedef __int64            sint64;  // 64-bit   signed
typedef __int64            Int64;   // 64-bit   signed

typedef double				sfloat64; // 64-bit signed

typedef union _Large_int {
    struct {
        uint32 LowPart;
        sint32 HighPart;
    };
    struct {
        uint32 LowPart;
        sint32 HighPart;
    } u;
    sint64 QuadPart;
} Large_int;

} // end namespace nbs

//---------------------------------------------------------------------------
#endif