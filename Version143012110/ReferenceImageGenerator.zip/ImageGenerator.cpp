// ImageGenerator.cpp : Implementation of CImageGenerator

#include "stdafx.h"
#include "ImageGenerator.h"
#include ".\imagegenerator.h"

using namespace nbs;

//---------------------------------------------------------------------------
// CImageGenerator
//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetType(ULONG type)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	type_ = nbs::Image_gen_type( type );
	return S_OK;
}

//---------------------------------------------------------------------------

void CImageGenerator::generate_local( nbs::Normalized_graphic& graphic, ULONG width, ULONG height )
{
	graphic.resize( width, height );
	switch( type_ ) {
		case GEN_GRADIENT: {
			gradient_func_.generate( graphic );
			break;
		}
		case GEN_RADIAL: {
			radial_func_.generate( graphic );
			break;
		}
		case GEN_CIRCULAR: {
			circular_func_.generate( graphic );
			break;
		}
		case GEN_GAUSSIAN: {
			gaussian_func_.generate( graphic );
			break;
		}
		case GEN_CHECKER_CIRCLE: {
			checker_circle_func_.generate( graphic );
			break;
		}
		case GEN_ELLIPSE: {
			ellipse_func_.generate( graphic );
			break;
		}
		case GEN_ANNULUS: {
			annulus_func_.generate( graphic );
			break;
		}
	}
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::Generate(ULONG width, ULONG height)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	generate_local( graphic_, width, height );
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::Multiply(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	if( graphic_.width() && graphic_.height() ) {
		nbs::Normalized_graphic graphic;
		generate_local( graphic, graphic_.width(), graphic_.height() );
		graphic_.multiply( graphic );
	}
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::Mask1(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	if( graphic_.width() && graphic_.height() ) {
		nbs::Normalized_graphic graphic;
		generate_local( graphic, graphic_.width(), graphic_.height() );
		graphic_.mask1( graphic );
	}
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::Mask2(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	if( graphic_.width() && graphic_.height() ) {
		nbs::Normalized_graphic graphic;
		generate_local( graphic, graphic_.width(), graphic_.height() );
		graphic_.mask2( graphic );
	}
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::Sum(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	if( graphic_.width() && graphic_.height() ) {
		nbs::Normalized_graphic graphic;
		generate_local( graphic, graphic_.width(), graphic_.height() );
		graphic_.sum( graphic );
	}
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::Min(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	if( graphic_.width() && graphic_.height() ) {
		nbs::Normalized_graphic graphic;
		generate_local( graphic, graphic_.width(), graphic_.height() );
		graphic_.minimum( graphic );
	}
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::Max(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	if( graphic_.width() && graphic_.height() ) {
		nbs::Normalized_graphic graphic;
		generate_local( graphic, graphic_.width(), graphic_.height() );
		graphic_.maximum( graphic );
	}
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::GenerateBitmap(BYTE* buffer, ULONG bpp, ULONG pitch, DOUBLE redBackground, DOUBLE redAmplitude, DOUBLE greenBackground, DOUBLE greenAmplitude, DOUBLE blueBackground, DOUBLE blueAmplitude)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	Surface_data sd;
	sd.ptr = buffer;
	sd.bit_count = bpp == 24 ? 24 : 32;
	sd.width = graphic_.width();
	sd.height = graphic_.height();
	sd.pitch = pitch;
	
	graphic_.construct_bitmap( sd, redBackground, redAmplitude, greenBackground, greenAmplitude, blueBackground, blueAmplitude );

	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetParamsGradient( DOUBLE angle, DOUBLE period, DOUBLE phase, SHORT square )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	gradient_func_.set_parameters( Angle::make_degrees(angle), period, Angle::make_degrees(phase), square != 0 );
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetParamsRadial( DOUBLE sfreq, DOUBLE phase, SHORT square )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	radial_func_.set_parameters( sfreq, Angle::make_degrees(phase), square != 0 );
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetParamsCircular( DOUBLE period, DOUBLE phase, SHORT square )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	circular_func_.set_parameters( period, Angle::make_degrees(phase), square != 0 );
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetParamsGaussian( DOUBLE mu, DOUBLE sigma )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	gaussian_func_.set_parameters( mu, sigma );
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetParamsCheckerCircle( DOUBLE angle, DOUBLE radius_inner, DOUBLE radius_outer, ULONG rings, ULONG slices, DOUBLE background )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	checker_circle_func_.set_parameters( Angle::make_degrees(angle), radius_inner, radius_outer, rings, slices, background );
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetParamsEllipse( DOUBLE width, DOUBLE height, DOUBLE angle )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	ellipse_func_.set_parameters( width, height, Angle::make_degrees(angle) );
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetParamsAnnulus( DOUBLE inner_width, DOUBLE inner_height, DOUBLE outer_width, DOUBLE outer_height, DOUBLE angle )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	annulus_func_.set_parameters( inner_width, inner_height, outer_width, outer_height, Angle::make_degrees(angle) );
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::GetSize( ULONG* width, ULONG* height )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	*width = graphic_.width();
	*height = graphic_.height();
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetOffset( DOUBLE offset_x, DOUBLE offset_y )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	gradient_func_.set_offset( offset_x, offset_y );
	radial_func_.set_offset( offset_x, offset_y );
	circular_func_.set_offset( offset_x, offset_y );
	gaussian_func_.set_offset( offset_x, offset_y );
	checker_circle_func_.set_offset( offset_x, offset_y );
	ellipse_func_.set_offset( offset_x, offset_y );
	annulus_func_.set_offset( offset_x, offset_y );
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetBackground( DOUBLE background )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	ellipse_func_.set_background( background );
	annulus_func_.set_background( background );
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP CImageGenerator::SetForeground( DOUBLE foreground )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	ellipse_func_.set_foreground( foreground );
	annulus_func_.set_foreground( foreground );
	return S_OK;
}

//---------------------------------------------------------------------------
