//---------------------------------------------------------------------------
#ifndef normalized_graphicH
#define normalized_graphicH
//---------------------------------------------------------------------------
#include "types.h"
#include "surface_data.h"
#include "xptr.h"
//---------------------------------------------------------------------------

namespace nbs {

/// Class that represents an image with one value per pixel in the range
/// [-1.0, 1.0].
///
/// The origin of the image in considered to be exactly halfway between the
/// rightmost/topmost and leftmost/bottommost pixels. Thus, for a 3x3 image,
/// the middle pixel has coorinates (0,0). For a 2x2 image, the upper-right 
/// pixel has coordinate (0.5,0.5). 
///
/// The y axis increases upward, the x axis to the right.
class Normalized_graphic
{
public:
	Normalized_graphic() : width_(0), height_(0) {}

	Normalized_graphic( unsigned int width, unsigned int height ) :
		width_( width ), height_( height ), buffer_( new Data_type[width * height] )
	{}
	
	/// \brief resize the image, destroying what was there
	void resize( unsigned int width, unsigned int height ) 
	{
		width_ = width;
		height_ = height;
		buffer_.reset( new Data_type[width * height] );
	}

	/// \brief Width of the image in pixels
	unsigned int width() const { return width_; }

	/// \brief Height of the image in pixels
	unsigned int height() const { return height_; }

	/// \brief data type
	typedef double Data_type;

	/// \Brief The data value that corresponds exactly to 1.0
	static const Data_type MAXIMUM_VALUE;

	/// \Brief The data value that corresponds exactly to -1.0
	static const Data_type MINIMUM_VALUE;

	/// \brief Access to the data buffer
	Data_type* buffer() { return buffer_.get(); }
	const Data_type* buffer() const { return buffer_.get(); }

	/// \brief Constructs a bitmap based on the normalized data 
	/// 
	/// Each color value of each pixel is given by: 
	/// color_value = background + value * amplitude 
	/// where the values are rounded to the nearest integer.
	/// This method does not protect against out of range values. 
	/// Background values are in the range [0,255].
	/// 
	/// \throw Exception bitmap is not 24/32 bit color, bitmap size 
	/// does not match this object's size 
	void construct_bitmap( Surface_data& bitmap, double red_background, double red_amplitude, 
		double green_background, double green_amplitude,  
		double blue_background, double blue_amplitude );

	/// \brief Multiplies this to graphic
	///
	/// The resulting values are conceptually (this * graphic).
	/// This method modifies this object, leaving the param alone
	///
	/// \param graphic Input graphic object.
	///
	/// \throw Exception if graphic is not same size as this object
	void multiply( const Normalized_graphic& graphic );

	/// \brief Masks this using graphic
	///
	/// The resulting values are conceptually (this * (graphic + 1) / 2)
	/// This method modifies this object, leaving the param alone
	///
	/// \param graphic Input graphic object.
	///
	/// \throw Exception if graphic is not same size as this object
	void mask1( const Normalized_graphic& graphic );

	/// \brief Masks graphic using this, with result in this
	///
	/// The resulting values are conceptually (graphic * (this + 1) / 2)
	/// This method modifies this object, leaving the param alone
	///
	/// \param graphic Input graphic object.
	///
	/// \throw Exception if graphic is not same size as this object
	void mask2( const Normalized_graphic& graphic );
	
	/// \brief Sum this to graphic / 2
	///
	/// The resulting values are conceptually (this + graphic) / 2
	/// This method modifies this object, leaving the param alone
	///
	/// \param graphic Input graphic object.
	///
	/// \throw Exception if graphic is not same size as this object
	void sum( const Normalized_graphic& graphic );
	
	/// \brief Sets value to minimum of this and argument's values
	///
	/// This method modifies this object, leaving the param alone
	///
	/// \param graphic Input graphic object.
	///
	/// \throw Exception if graphic is not same size as this object
	void minimum( const Normalized_graphic& graphic );
	
	/// \brief Sets value to maximum of this and argument's values
	///
	/// This method modifies this object, leaving the param alone
	///
	/// \param graphic Input graphic object.
	///
	/// \throw Exception if graphic is not same size as this object
	void maximum( const Normalized_graphic& graphic );

private:
	Normalized_graphic( const Normalized_graphic& );
	void operator=( const Normalized_graphic& );

	template <class T>
	void transform( const Normalized_graphic& g );

	Array_auto_ptr<Data_type> buffer_;
	unsigned int width_;
	unsigned int height_;
};

} // namespace nbs

//---------------------------------------------------------------------------
#endif
