//---------------------------------------------------------------------------
#ifndef angleH
#define angleH
//---------------------------------------------------------------------------

namespace nbs {

static const double ANGLE_PI = 3.1415926535897932384626433832795;
static const double DEGREES_PER_RADIAN = 180.0 / ANGLE_PI;
static const double RADIANS_PER_DEGREE = ANGLE_PI / 180.0;

/// \brief Contains the value of an angle with units
class Angle 
{
public:
	Angle() : radians_(0) {}
	double radians() const
	{
		return radians_;
	}
	double degrees() const
	{
		return radians_ * DEGREES_PER_RADIAN;
	}
	void set_radians( double radians ) 
	{
		radians_ = radians;
	}
	void set_degrees( double degrees ) 
	{
		radians_ = degrees * RADIANS_PER_DEGREE;
	}
	Angle& operator+=( const Angle& a )
	{
		radians_ += a.radians_;
		return *this;
	}
	Angle& operator-=( const Angle& a )
	{
		radians_ -= a.radians_;
		return *this;
	}
	Angle& operator*=( double d )
	{
		radians_ *= d;
		return *this;
	}
	Angle& operator/=( double d )
	{
		radians_ /= d;
		return *this;
	}
	
	static Angle make_radians( double radians ) 
	{
		return Angle( radians );
	}
	static Angle make_degrees( double degrees ) 
	{
		return Angle( degrees * RADIANS_PER_DEGREE );
	}

private:
	Angle( double radians ) : radians_( radians ) {}
	double radians_;
};

inline bool operator==( const Angle& d1, const Angle& d2 ) {
	return d1.radians() == d2.radians();
}
inline bool operator!=( const Angle& d1, const Angle& d2 ) {
	return d1.radians() != d2.radians();
}
inline bool operator<( const Angle& d1, const Angle& d2 ) {
	return d1.radians() < d2.radians();
}
inline bool operator>( const Angle& d1, const Angle& d2 ) {
	return d1.radians() > d2.radians();
}
inline bool operator<=( const Angle& d1, const Angle& d2 ) {
	return d1.radians() <= d2.radians();
}
inline bool operator>=( const Angle& d1, const Angle& d2 ) {
	return d1.radians() >= d2.radians();
}
inline Angle operator+( const Angle& a1, const Angle& a2 )
{
	return Angle::make_radians( a1.radians() + a2.radians() );
}
inline Angle operator-( const Angle& a1, const Angle& a2 )
{
	return Angle::make_radians( a1.radians() - a2.radians() );
}
inline Angle operator*( const Angle& a1, double d )
{
	return Angle::make_radians( a1.radians() * d );
}
inline Angle operator*( double d, const Angle& a1 )
{
	return Angle::make_radians( a1.radians() * d );
}
inline Angle operator/( const Angle& a1, double d )
{
	return Angle::make_radians( a1.radians() / d );
}

}; // namespace nbs

//---------------------------------------------------------------------------
#endif