//---------------------------------------------------------------------------
#ifndef image_gen_typeH
#define image_gen_typeH
//---------------------------------------------------------------------------

namespace nbs {

enum Image_gen_type { GEN_GRADIENT=0, GEN_RADIAL=1, GEN_CIRCULAR=2, GEN_GAUSSIAN=3, GEN_CHECKER_CIRCLE=4, GEN_ELLIPSE=5, GEN_ANNULUS=6 };

}; // end namespace nbs

//---------------------------------------------------------------------------
#endif
