//---------------------------------------------------------------------------
#ifndef xptrH
#define xptrH
//---------------------------------------------------------------------------

namespace nbs {

// class that contains the reference count used by the Xptr class
// objects placed into Xptr's must descend from Auto_object
// WARNING: watch out for multiple Auto_object base classes as this will
// cause leaks or access violations. When in doublt, use virtual inheritance
class Auto_object
{
public:
   Auto_object() : users( 0 ) {}   
   Auto_object( const Auto_object& ) : users( 0 ) {}
   Auto_object& operator=( const Auto_object& ) { return *this; }
   void xptr_acquire() const { users++; }
   int xptr_release() const { return --users; }
   int get_users() const { return users; }
   virtual ~Auto_object() {}
private:
   mutable int users;
};  

// reference counted pointer class
// used with objects that descend from Auto_object
template<class X>
class Xptr
{
public:
   Xptr() : ptr( 0 ) {}
   Xptr( X* p ) : ptr( p ) { if (ptr) ptr->xptr_acquire(); }
   Xptr( const Xptr<X>& r ) : ptr( r.get() ) { if (ptr) ptr->xptr_acquire(); }
   //allows for conversion of Xptrs to classes descending from X
   template<class Y>
   Xptr( Y* p ) : ptr( p ) { if (ptr) ptr->xptr_acquire(); }
   //allows for conversion of Xptrs to classes descending from X
   template<class Y>
   Xptr( const Xptr<Y>& r ) : ptr( r.get() ) { if (ptr) ptr->xptr_acquire(); }
   ~Xptr() { if (ptr) { if (!ptr->xptr_release()) delete ptr; } }
   void operator= (const Xptr<X>& r) {
      if ( (ptr) && (!ptr->xptr_release()) ) delete ptr;
      ptr = r.get();
      if (ptr) ptr->xptr_acquire();
   }
   template<class Y>
   void operator= (const Xptr<Y>& r) {
      if ( (ptr) && (!ptr->xptr_release()) ) delete ptr;
      ptr = r.get();
      if (ptr) ptr->xptr_acquire();
   }
   X& operator* () const { return *ptr; }
   X* operator-> () const { return ptr; }
   X* get() const { return ptr; }
   void reset( X* p ) {
      if ( (ptr) && (!ptr->xptr_release()) ) delete ptr;
      ptr = p;
      if (ptr) ptr->xptr_acquire();
   }
   bool operator<( const Xptr<X>& p ) const { return ptr < p.ptr; }
   bool operator==( const Xptr<X>& p ) const { return ptr == p.ptr; }
   bool operator!=( const Xptr<X>& p ) const { return ptr != p.ptr; }
   bool operator!() const { return !ptr; }

private:
   X* ptr;
};                

//holds either a raw pointer or an Xptr
//must be used with types that descend from Auto_object
template<class X>
class Dual_ptr
{
public:
   Dual_ptr() : ptr( 0 ) {}
   Dual_ptr( X* p ) : ptr( p ) {}
   Dual_ptr( Xptr<X> p ) : ptr( p.get() ), xptr( p ) {}
   X& operator* () const { return *ptr; }
   X* operator-> () const { return ptr; }
   X* get() const { return ptr; }
   void reset( X* p ) {
      ptr = p;
      xptr.reset( p );
   }
   bool operator==( Dual_ptr<X> rhs ) const
   {
	   return get() == rhs.get();
   }

private:
   X* ptr;
   Xptr<X> xptr;
};         

// an auto_ptr for arrays
template<class X>
class Array_auto_ptr
{
public:
   Array_auto_ptr() : ptr( 0 ) {}
   Array_auto_ptr( X* p ) : ptr( p ) {}
   Array_auto_ptr( Array_auto_ptr<X>& r ) : ptr( r.release() ) {}
   ~Array_auto_ptr() { if (ptr) delete[] ptr; }
   void operator= ( Array_auto_ptr<X>& r) {
      if (ptr) delete[] ptr;
      ptr = r.release();
   }
   X& operator[]( unsigned int index ) {
      return *(ptr + index);
   }
   const X& operator[]( unsigned int index ) const  {
      return *(ptr + index);
   }
   X* get() const { return ptr; }
   X* release() { X* temp = ptr; ptr = 0; return temp; }
   void reset( X* p ) {
      if (ptr) delete[] ptr;
      ptr = p;
   }
private:
   X* ptr;
};

} // namespace nbs

//---------------------------------------------------------------------------
#endif