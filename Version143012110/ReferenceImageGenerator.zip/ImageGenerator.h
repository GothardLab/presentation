// ImageGenerator.h : Declaration of the CImageGenerator

#pragma once
#include "resource.h"       // main symbols

#include "ReferenceImageGenerator.h"
#include "image_gen_type.h"
#include "graphic_function.h"


// CImageGenerator

class ATL_NO_VTABLE CImageGenerator : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CImageGenerator, &CLSID_ImageGenerator>,
	public IImageGenerator
{
public:
	CImageGenerator()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_IMAGEGENERATOR)

DECLARE_NOT_AGGREGATABLE(CImageGenerator)

BEGIN_COM_MAP(CImageGenerator)
	COM_INTERFACE_ENTRY(IImageGenerator)
END_COM_MAP()


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

private:
	void generate_local( nbs::Normalized_graphic& graphic, ULONG width, ULONG height );
	nbs::Image_gen_type type_;
	nbs::Normalized_graphic graphic_;
	nbs::Gradient_graphic_function gradient_func_;
	nbs::Radial_graphic_function radial_func_;
	nbs::Circular_graphic_function circular_func_;
	nbs::Gaussian_graphic_function gaussian_func_;
	nbs::Checker_circle_graphic_function checker_circle_func_;
	nbs::Ellipse_graphic_function ellipse_func_;
	nbs::Annulus_graphic_function annulus_func_;

public:

	STDMETHOD(SetType)(ULONG type);
	STDMETHOD(Generate)(ULONG width, ULONG height);
	STDMETHOD(Multiply)(void);
	STDMETHOD(Mask1)(void);
	STDMETHOD(Mask2)(void);
	STDMETHOD(Sum)(void);
	STDMETHOD(Min)(void);
	STDMETHOD(Max)(void);
	STDMETHOD(GenerateBitmap)(BYTE* buffer, ULONG bpp, ULONG pitch, DOUBLE redBackground, DOUBLE redAmplitude, DOUBLE greenBackground, DOUBLE greenAmplitude, DOUBLE blueBackground, DOUBLE blueAmplitude);
	STDMETHOD(SetParamsGradient)( DOUBLE angle, DOUBLE period, DOUBLE phase, SHORT square );
	STDMETHOD(SetParamsRadial)( DOUBLE sfreq, DOUBLE phase, SHORT square );
	STDMETHOD(SetParamsCircular)( DOUBLE period, DOUBLE phase, SHORT square );
	STDMETHOD(SetParamsGaussian)( DOUBLE mu, DOUBLE sigma );
	STDMETHOD(SetParamsCheckerCircle)( DOUBLE angle, DOUBLE radius_inner, DOUBLE radius_outer, ULONG rings, ULONG slices, DOUBLE background );
	STDMETHOD(SetParamsEllipse)( DOUBLE width, DOUBLE height, DOUBLE angle );
	STDMETHOD(SetParamsAnnulus)( DOUBLE inner_width, DOUBLE inner_height, DOUBLE outer_width, DOUBLE outer_height, DOUBLE angle );
	STDMETHOD(GetSize)(ULONG* width, ULONG* height);
	STDMETHOD(SetOffset)( DOUBLE offset_x, DOUBLE offset_y );
	STDMETHOD(SetForeground)( DOUBLE foreground );
	STDMETHOD(SetBackground)( DOUBLE background );
};

OBJECT_ENTRY_AUTO(__uuidof(ImageGenerator), CImageGenerator)
