// ReferenceImageGenerator.h : main header file for the ReferenceImageGenerator DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "ReferenceImageGenerator_i.h"


// CReferenceImageGeneratorApp
// See ReferenceImageGenerator.cpp for the implementation of this class
//

class CReferenceImageGeneratorApp : public CWinApp
{
public:
	CReferenceImageGeneratorApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
