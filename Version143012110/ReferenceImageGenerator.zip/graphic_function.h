//---------------------------------------------------------------------------
#ifndef graphic_functionH
#define graphic_functionH
//---------------------------------------------------------------------------
#include "normalized_graphic.h"
#include "angle.h"
//---------------------------------------------------------------------------

namespace nbs {
	namespace graphic_const {
		static const double G_PI = 3.1415926535897932384626433832795;
		static const double G_2PI = 2.0 * G_PI;
		static const double G_HALF_PI = 0.5 * G_PI;
		static const double G_INV_PI = 1.0 / G_PI;
		static const double G_INV_2PI = 1.0 / G_2PI;
	};

/// \brief objects that generate normalized graphics (parent class)
class Graphic_function
{
public:
	/// \brief Constructs a bitmap based on whatever parameters the object has.
	virtual void generate( Normalized_graphic& graphic ) const = 0;

	/// \brief Sets the offset coordinates
	virtual void set_offset( double x, double y ) {
		offset_x_ = x;
		offset_y_ = y;
	}

	Graphic_function() : offset_x_(0), offset_y_(0) {}
	virtual ~Graphic_function() {}

protected:	
	double offset_x_, offset_y_;
};

/// Function that generates a graphic based on the following formula:
/// sin( 360 * (cos(angle) * x + sin(-angle) * y) / period + phase )
/// x goes from -width/2 + 0.5 to width/2 + 0.5
/// y goes from -height/2 + 0.5 to height/2 + 0.5
class Gradient_graphic_function : public Graphic_function
{
public:
	Gradient_graphic_function( Angle angle=Angle::make_radians(0), double period=0.05
		, Angle phase=Angle::make_radians(0), bool square=false )
		: angle_(angle), period_(period), phase_(phase), square_(square) {}

	virtual void generate( Normalized_graphic& graphic ) const;

	void set_parameters( Angle angle, double period, Angle phase, bool square )
	{
		angle_ = angle;
		period_ = period;
		phase_ = phase;
		square_ = square;
	}

private:
	Angle angle_;
	double period_;
	Angle phase_;
	bool square_;
};

/// Function that generates a graphic based on the following formula:
/// sin( phase_ + sfreq_ * atan( y, x ) )
/// The middle pixel is defined to be 0
class Radial_graphic_function : public Graphic_function
{
public:
	Radial_graphic_function() : sfreq_(1.0), phase_(Angle::make_radians(0.0)), square_(false) {}

	virtual void generate( Normalized_graphic& graphic ) const;

	/// \param sfreq frequency in cycles per 360 degrees
	///
	/// \param square whether to use square or sine
	void set_parameters( double sfreq, Angle phase, bool square )
	{
		sfreq_ = sfreq > 0 ? sfreq : -sfreq;
		phase_ = phase;
		square_ = square;
	}
private:
	double sfreq_;
	Angle phase_;
	bool square_;
};

/// Function that generates a graphic according to the following formula:
/// sin( sqrt(x * x + y * y) * 360 / period_ + phase_ );
class Circular_graphic_function : public Graphic_function
{
public:
	Circular_graphic_function() : period_(100.0), phase_(Angle::make_radians(0.0)), square_(false) {}

	virtual void generate( Normalized_graphic& graphic ) const;

	void set_parameters( double period, Angle phase, bool square )
	{
		period_ = period;
		phase_ = phase;
		square_ = square;
	}
private:
	double period_;
	Angle phase_;
	bool square_;
};

/// Function that generates a circle with checkers
class Checker_circle_graphic_function : public Graphic_function
{
public:
	Checker_circle_graphic_function() : phase_(Angle::make_radians(0.0)), radius_inner_(100.0), radius_outer_(300.0)
		, rings_(4), slices_(8), background_(0.5) {}

	virtual void generate( Normalized_graphic& graphic ) const;

	void set_parameters( Angle phase, double radius_inner, double radius_outer, uint32 rings
		, uint32 slices, double background )
	{
		phase_ = phase;
		radius_inner_ = radius_inner;
		radius_outer_ = radius_outer;
		rings_ = rings;
		slices_ = slices;
		background_ = background;
	}
private:
	Angle phase_;
	double radius_inner_;
	double radius_outer_;
	int rings_;
	int slices_;
	double background_;
};

/// Function that generates a graphic according to the following formula:
/// (exp( -(r-mu) ^ 2 / 2 / sigma^2 ) + 1) / 2
class Gaussian_graphic_function : public Graphic_function
{
public:
	Gaussian_graphic_function() : mu_(0), sigma_(127.5) {}

	virtual void generate( Normalized_graphic& graphic ) const;

	void set_parameters( double mu, double sigma )
	{
		mu_ = mu;
		sigma_ = sigma;
	}

private:
	double mu_;
	double sigma_;
};

/// Generates an ellipse of value 1 with a given height and width and rotated
/// clockwise by an angle. The background has value -1
class Ellipse_graphic_function : public Graphic_function
{
public:
	Ellipse_graphic_function() : width_(100), height_(70)
		, angle_(Angle::make_radians(0))
		, foreground_( 1.0 ), background_(-1.0) {}
	virtual void generate( Normalized_graphic& graphic ) const;

	void set_parameters( double width, double height, Angle angle )
	{
		// If width is less than
		// height, we swap the two dimentions and rotate 90 degrees.
		if( width > height ) {
			width_ = width;
			height_ = height;
			angle_ = angle;
		} else {
			width_ = height;
			height_ = width;
			angle_ = angle + Angle::make_radians( graphic_const::G_HALF_PI );
		}
	}
	void set_foreground( double foreground ) { foreground_ = foreground; }
	void set_background( double background ) { background_ = background; }
private:
	double width_;
	double height_;
	Angle angle_;
	double foreground_;
	double background_;
};

/// Function that generates an elliptical band using two ellipses
class Annulus_graphic_function : public Graphic_function
{
public:
	Annulus_graphic_function() : outer_width_(100), outer_height_(70), inner_width_(60)
		, inner_height_(20), angle1_(Angle::make_radians(0)), angle2_(Angle::make_radians(0))
		, foreground_( 1.0 ), background_(-1.0) {}
	virtual void generate( Normalized_graphic& graphic ) const;

	void set_parameters( double inner_width, double inner_height, double outer_width, double outer_height, Angle angle )
	{
		// If width is less than
		// height, we swap the two dimentions and rotate 90 degrees.
		if( outer_width > outer_height ) {
			outer_width_ = outer_width;
			outer_height_ = outer_height;
			angle1_ = angle;
		} else {
			outer_width_ = outer_height;
			outer_height_ = outer_width;
			angle1_ = angle + Angle::make_radians( graphic_const::G_HALF_PI );
		}
		if( inner_width > inner_height ) {
			inner_width_ = inner_width;
			inner_height_ = inner_height;
			angle2_ = angle;
		} else {
			inner_width_ = inner_height;
			inner_height_ = inner_width;
			angle2_ = angle + Angle::make_radians( graphic_const::G_HALF_PI );
		}
	}
	void set_foreground( double foreground ) { foreground_ = foreground; }
	void set_background( double background ) { background_ = background; }
private:
	double inner_width_;
	double inner_height_;
	double outer_width_;
	double outer_height_;
	Angle angle1_;
	Angle angle2_;
	double foreground_;
	double background_;
};

} // namespace nbs

//---------------------------------------------------------------------------
#endif































