#include "stdafx.h"
#include "graphic_function.h"
#include "exception.h"

using namespace nbs;
using namespace nbs::graphic_const;

//---------------------------------------------------------------------------
//
// utility functions
//
//--------------------------------------------------------------------------- 

// returns a positive value for angle in radians (0 to 2pi)
inline double pos_pi( double r )
{
	if( r > G_2PI ) {
		r = r - (G_2PI * double(int(r * G_INV_2PI)));
	} else if( r < 0.0 ) {
		r = r + (G_2PI * double(int(1.0 - (r * G_INV_2PI))));
	}
	return r;
}

//---------------------------------------------------------------------------
//
// class Gradient_graphic_function
//
//--------------------------------------------------------------------------- 

void Gradient_graphic_function::generate( Normalized_graphic& graphic ) const
{
	int graphic_width = graphic.width();
	int graphic_height = graphic.height();

	double left = -graphic_width * 0.5 + 0.5 - offset_x_;
	double top = -graphic_height * 0.5 + 0.5 + offset_y_;

	Normalized_graphic::Data_type* ptr = graphic.buffer();

	double y = top;
	for( int yi = 0; yi < graphic_height; ++yi, ++y ) 
	{
		double x = left;
		for( int xi = 0; xi < graphic_width; ++xi, ++x ) 
		{
			*(ptr) = sin( G_2PI * (cos(-angle_.radians()) * x + sin(angle_.radians()) * y) / period_ + 
				phase_.radians() );
			if (square_)
			{
				if (*ptr >= 0)
				{
					*ptr = 1.0;
				}
				else
				{
					*ptr = -1.0;
				}
			}
			++ptr;
		}
	}
}

//---------------------------------------------------------------------------
//
// class Radial_graphic_function
//
//--------------------------------------------------------------------------- 

void Radial_graphic_function::generate( Normalized_graphic& graphic ) const
{
	int graphic_width = graphic.width();
	int graphic_height = graphic.height();

	double left = -graphic_width * 0.5 + 0.5 - offset_x_;
	double top = -graphic_height * 0.5 + 0.5 + offset_y_;
	Normalized_graphic::Data_type* ptr = graphic.buffer();

	double y = top;
	for( int yi = graphic_height; yi > 0; --yi, ++y ) 
	{
		double x = left;
		for( int xi = graphic_width; xi > 0; --xi, ++x ) 
		{
			*(ptr) = sin( sfreq_ * atan2( y, x ) - phase_.radians() );
			if (square_)
			{
				if (*ptr >= 0)
				{
					*ptr = 1.0;
				}
				else
				{
					*ptr = -1.0;
				}
			}
			++ptr;
		}
	}
}

//---------------------------------------------------------------------------
//
// class Circular_graphic_function
//
//--------------------------------------------------------------------------- 

void Circular_graphic_function::generate(  Normalized_graphic& graphic ) const
{
	double freq = G_2PI / period_;

	int graphic_width = graphic.width();
	int graphic_height = graphic.height();

	double left = -graphic_width * 0.5 + 0.5 - offset_x_;
	double top = -graphic_height * 0.5 + 0.5 + offset_y_;
	
	Normalized_graphic::Data_type* ptr = graphic.buffer();

	double y = top;
	for( int yi = 0; yi < graphic_height; ++yi, ++y ) 
	{
		double x = left;
		for( int xi = 0; xi < graphic_width; ++xi, ++x ) 
		{
			*(ptr) = sin( sqrt(x * x + y * y) * freq + phase_.radians() );
			if (square_)
			{
				if (*ptr >= 0)
				{
					*ptr = 1.0;
				}
				else
				{
					*ptr = -1.0;
				}
			}
			++ptr;
		}
	}
}

//---------------------------------------------------------------------------
//
// class Checker_circle_graphic_function
//
//---------------------------------------------------------------------------

void Checker_circle_graphic_function::generate( Normalized_graphic& graphic ) const
{
	int graphic_width = graphic.width();
	int graphic_height = graphic.height();

	double left = -double(graphic_width) * 0.5 + 0.5 - offset_x_;
	double top = -double(graphic_height) * 0.5 + 0.5 + offset_y_;

	Normalized_graphic::Data_type* ptr = graphic.buffer();

	double inverse_radial_thickness = 1.0;
	if( radius_outer_ > radius_inner_ ) 
	{
		inverse_radial_thickness = double(rings_) / (radius_outer_ - radius_inner_);
	}

	for( int yi = 0; yi < graphic_height; ++yi ) 
	{
		double y = top + double(yi);
		double x = left;
		double ysqr = y * y;
		for( int xi = 0; xi < graphic_width; xi++ ) 
		{
			double d = sqrt( x * x + ysqr );
			if( d >= radius_outer_ || d <= radius_inner_ ) 
			{
				*(ptr++) = background_;
			} 
			else 
			{
				double at = atan2( y, x );
				if( at < 0 ) { at += G_2PI; }
				uint32 a = uint32( (slices_ * at + pos_pi(-phase_.radians())) * G_INV_PI );
				uint32 dd = uint32( inverse_radial_thickness * (d - radius_inner_) );
				a += dd;
				if( a % 2 ) {
					*(ptr++) = 1.0;
				} else {
					*(ptr++) = -1.0;
				}
			}
			x++;
		}
	}
}

//---------------------------------------------------------------------------
//
// class Gaussian_graphic_function
//
//---------------------------------------------------------------------------

void Gaussian_graphic_function::generate( Normalized_graphic& graphic ) const
{
	int graphic_width = graphic.width();
	int graphic_height = graphic.height();

	double left = -graphic_width * 0.5 + 0.5 - offset_x_;
	double top = -graphic_height * 0.5 + 0.5 + offset_y_;
	
	const double sqrt_half = sqrt( 0.5 );

	Normalized_graphic::Data_type* ptr = graphic.buffer();
	double y = top;
	for( int yi = 0; yi < graphic_height; ++yi, ++y ) 
	{
		double x = left;
		for( int xi = 0; xi < graphic_width; ++xi, ++x ) 
		{
			double d = (sqrt( x * x + y * y ) - mu_) * sqrt_half / sigma_;
			*(ptr++) = exp( -d * d ) * 2 - 1;
		}
	}
}

//---------------------------------------------------------------------------
//
// class Ellipse_graphic_function
//
//---------------------------------------------------------------------------

void Ellipse_graphic_function::generate( Normalized_graphic& graphic ) const
{
	int graphic_width = graphic.width();
	int graphic_height = graphic.height();
	double left = -double(graphic_width) * 0.5 + 0.5 - offset_x_;
	double top = -double(graphic_height) * 0.5 + 0.5 + offset_y_;

	double radius1 = width_ * 0.5;
	double radius2 = height_ * 0.5;
	double c = sqrt( (radius1 * radius1) - (radius2 * radius2) );
	double x1 = c * cos( -angle_.radians() );
	double y1 = c * sin( angle_.radians() );
	double x2 = -x1;
	double y2 = -y1;
	
	Normalized_graphic::Data_type* ptr = graphic.buffer();
	double y = top;
	for( int yi = graphic_height; yi > 0; --yi, ++y ) 
	{
		double x = left;
		for( int xi = graphic_width; xi > 0; --xi, ++x ) 
		{
			double dx1 = x1 - x;
			double dy1 = y1 - y;
			double dx2 = x2 - x;
			double dy2 = y2 - y;
			double dist = sqrt(dx1 * dx1 + dy1 * dy1) + sqrt(dx2 * dx2 + dy2 * dy2);
			if( dist >= width_ ) 
			{
				(*ptr++) = background_;
			} 
			else 
			{
				(*ptr++) = foreground_;
			}
		}
	}
}

//---------------------------------------------------------------------------
//
// class Annulus_graphic_function
//
//---------------------------------------------------------------------------

void Annulus_graphic_function::generate( Normalized_graphic& graphic ) const
{
	int graphic_width = graphic.width();
	int graphic_height = graphic.height();
	double left = -double(graphic_width) * 0.5 + 0.5 - offset_x_;
	double top = -double(graphic_height) * 0.5 + 0.5 + offset_y_;

	double radius1 = outer_width_ * 0.5;
	double radius2 = outer_height_ * 0.5;
	double c = sqrt( (radius1 * radius1) - (radius2 * radius2) );
	double x1 = c * cos( -angle1_.radians() );
	double y1 = c * sin( angle1_.radians() );
	double x2 = -x1;
	double y2 = -y1;

	radius1 = inner_width_ * 0.5;
	radius2 = inner_height_ * 0.5;
	c = sqrt( (radius1 * radius1) - (radius2 * radius2) );
	double x3 = c * cos( -angle2_.radians() );
	double y3 = c * sin( angle2_.radians() );
	double x4 = -x3;
	double y4 = -y3;

	Normalized_graphic::Data_type* ptr = graphic.buffer();
	double y = top;
	for( int yi = graphic_height; yi > 0; --yi, ++y ) 
	{
		double x = left;
		for( int xi = graphic_width; xi > 0; --xi, ++x ) 
		{
			double dx1 = x1 - x;
			double dy1 = y1 - y;
			double dx2 = x2 - x;
			double dy2 = y2 - y;
			double dist = sqrt(dx1 * dx1 + dy1 * dy1) + sqrt(dx2 * dx2 + dy2 * dy2);
			if( dist >= outer_width_) 
			{
				(*ptr++) = background_;
			} 
			else 
			{
				dx1 = x3 - x;
				dy1 = y3 - y;
				dx2 = x4 - x;
				dy2 = y4 - y;
				dist = sqrt(dx1 * dx1 + dy1 * dy1) + sqrt(dx2 * dx2 + dy2 * dy2);
				if( dist > inner_width_) 
				{
					(*ptr++) = foreground_;
				} 
				else 
				{
					(*ptr++) = background_;
				}
			}
		}
	}
}

//--------------------------------------------------------------------------- 

