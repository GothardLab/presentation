

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Fri Jan 22 12:36:47 2010
 */
/* Compiler settings for .\ReferenceImageGenerator.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ReferenceImageGenerator_i_h__
#define __ReferenceImageGenerator_i_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IImageGenerator_FWD_DEFINED__
#define __IImageGenerator_FWD_DEFINED__
typedef interface IImageGenerator IImageGenerator;
#endif 	/* __IImageGenerator_FWD_DEFINED__ */


#ifndef __ImageGenerator_FWD_DEFINED__
#define __ImageGenerator_FWD_DEFINED__

#ifdef __cplusplus
typedef class ImageGenerator ImageGenerator;
#else
typedef struct ImageGenerator ImageGenerator;
#endif /* __cplusplus */

#endif 	/* __ImageGenerator_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __IImageGenerator_INTERFACE_DEFINED__
#define __IImageGenerator_INTERFACE_DEFINED__

/* interface IImageGenerator */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IImageGenerator;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A170B24A-96C0-453B-BEF1-85487F3BF9EB")
    IImageGenerator : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetType( 
            /* [in] */ ULONG type) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Generate( 
            /* [in] */ ULONG width,
            /* [in] */ ULONG height) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Multiply( void) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Mask1( void) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Mask2( void) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Sum( void) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Min( void) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Max( void) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GenerateBitmap( 
            /* [out] */ BYTE *buffer,
            /* [in] */ ULONG bpp,
            /* [in] */ ULONG pitch,
            /* [in] */ DOUBLE redBackground,
            /* [in] */ DOUBLE redAmplitude,
            /* [in] */ DOUBLE greenBackground,
            /* [in] */ DOUBLE greenAmplitude,
            /* [in] */ DOUBLE blueBackground,
            /* [in] */ DOUBLE blueAmplitude) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetParamsGradient( 
            /* [in] */ DOUBLE angle,
            /* [in] */ DOUBLE period,
            /* [in] */ DOUBLE phase,
            /* [in] */ SHORT square) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetParamsRadial( 
            /* [in] */ DOUBLE sfreq,
            /* [in] */ DOUBLE phase,
            /* [in] */ SHORT square) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetParamsCircular( 
            /* [in] */ DOUBLE period,
            /* [in] */ DOUBLE phase,
            /* [in] */ SHORT square) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetParamsGaussian( 
            /* [in] */ DOUBLE mu,
            /* [in] */ DOUBLE sigma) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetParamsCheckerCircle( 
            /* [in] */ DOUBLE angle,
            /* [in] */ DOUBLE radius_inner,
            /* [in] */ DOUBLE radius_outer,
            /* [in] */ ULONG rings,
            /* [in] */ ULONG slices,
            /* [in] */ DOUBLE background) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetParamsEllipse( 
            /* [in] */ DOUBLE width,
            /* [in] */ DOUBLE height,
            /* [in] */ DOUBLE angle) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetParamsAnnulus( 
            /* [in] */ DOUBLE inner_width,
            /* [in] */ DOUBLE inner_height,
            /* [in] */ DOUBLE outer_width,
            /* [in] */ DOUBLE outer_height,
            /* [in] */ DOUBLE angle) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetSize( 
            /* [out] */ ULONG *width,
            /* [out] */ ULONG *height) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetOffset( 
            /* [in] */ DOUBLE offset_x,
            /* [in] */ DOUBLE offset_y) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetForeground( 
            /* [in] */ DOUBLE foreground) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetBackground( 
            /* [in] */ DOUBLE background) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IImageGeneratorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IImageGenerator * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IImageGenerator * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IImageGenerator * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetType )( 
            IImageGenerator * This,
            /* [in] */ ULONG type);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *Generate )( 
            IImageGenerator * This,
            /* [in] */ ULONG width,
            /* [in] */ ULONG height);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *Multiply )( 
            IImageGenerator * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *Mask1 )( 
            IImageGenerator * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *Mask2 )( 
            IImageGenerator * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *Sum )( 
            IImageGenerator * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *Min )( 
            IImageGenerator * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *Max )( 
            IImageGenerator * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *GenerateBitmap )( 
            IImageGenerator * This,
            /* [out] */ BYTE *buffer,
            /* [in] */ ULONG bpp,
            /* [in] */ ULONG pitch,
            /* [in] */ DOUBLE redBackground,
            /* [in] */ DOUBLE redAmplitude,
            /* [in] */ DOUBLE greenBackground,
            /* [in] */ DOUBLE greenAmplitude,
            /* [in] */ DOUBLE blueBackground,
            /* [in] */ DOUBLE blueAmplitude);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetParamsGradient )( 
            IImageGenerator * This,
            /* [in] */ DOUBLE angle,
            /* [in] */ DOUBLE period,
            /* [in] */ DOUBLE phase,
            /* [in] */ SHORT square);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetParamsRadial )( 
            IImageGenerator * This,
            /* [in] */ DOUBLE sfreq,
            /* [in] */ DOUBLE phase,
            /* [in] */ SHORT square);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetParamsCircular )( 
            IImageGenerator * This,
            /* [in] */ DOUBLE period,
            /* [in] */ DOUBLE phase,
            /* [in] */ SHORT square);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetParamsGaussian )( 
            IImageGenerator * This,
            /* [in] */ DOUBLE mu,
            /* [in] */ DOUBLE sigma);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetParamsCheckerCircle )( 
            IImageGenerator * This,
            /* [in] */ DOUBLE angle,
            /* [in] */ DOUBLE radius_inner,
            /* [in] */ DOUBLE radius_outer,
            /* [in] */ ULONG rings,
            /* [in] */ ULONG slices,
            /* [in] */ DOUBLE background);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetParamsEllipse )( 
            IImageGenerator * This,
            /* [in] */ DOUBLE width,
            /* [in] */ DOUBLE height,
            /* [in] */ DOUBLE angle);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetParamsAnnulus )( 
            IImageGenerator * This,
            /* [in] */ DOUBLE inner_width,
            /* [in] */ DOUBLE inner_height,
            /* [in] */ DOUBLE outer_width,
            /* [in] */ DOUBLE outer_height,
            /* [in] */ DOUBLE angle);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetSize )( 
            IImageGenerator * This,
            /* [out] */ ULONG *width,
            /* [out] */ ULONG *height);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetOffset )( 
            IImageGenerator * This,
            /* [in] */ DOUBLE offset_x,
            /* [in] */ DOUBLE offset_y);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetForeground )( 
            IImageGenerator * This,
            /* [in] */ DOUBLE foreground);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetBackground )( 
            IImageGenerator * This,
            /* [in] */ DOUBLE background);
        
        END_INTERFACE
    } IImageGeneratorVtbl;

    interface IImageGenerator
    {
        CONST_VTBL struct IImageGeneratorVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IImageGenerator_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IImageGenerator_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IImageGenerator_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IImageGenerator_SetType(This,type)	\
    (This)->lpVtbl -> SetType(This,type)

#define IImageGenerator_Generate(This,width,height)	\
    (This)->lpVtbl -> Generate(This,width,height)

#define IImageGenerator_Multiply(This)	\
    (This)->lpVtbl -> Multiply(This)

#define IImageGenerator_Mask1(This)	\
    (This)->lpVtbl -> Mask1(This)

#define IImageGenerator_Mask2(This)	\
    (This)->lpVtbl -> Mask2(This)

#define IImageGenerator_Sum(This)	\
    (This)->lpVtbl -> Sum(This)

#define IImageGenerator_Min(This)	\
    (This)->lpVtbl -> Min(This)

#define IImageGenerator_Max(This)	\
    (This)->lpVtbl -> Max(This)

#define IImageGenerator_GenerateBitmap(This,buffer,bpp,pitch,redBackground,redAmplitude,greenBackground,greenAmplitude,blueBackground,blueAmplitude)	\
    (This)->lpVtbl -> GenerateBitmap(This,buffer,bpp,pitch,redBackground,redAmplitude,greenBackground,greenAmplitude,blueBackground,blueAmplitude)

#define IImageGenerator_SetParamsGradient(This,angle,period,phase,square)	\
    (This)->lpVtbl -> SetParamsGradient(This,angle,period,phase,square)

#define IImageGenerator_SetParamsRadial(This,sfreq,phase,square)	\
    (This)->lpVtbl -> SetParamsRadial(This,sfreq,phase,square)

#define IImageGenerator_SetParamsCircular(This,period,phase,square)	\
    (This)->lpVtbl -> SetParamsCircular(This,period,phase,square)

#define IImageGenerator_SetParamsGaussian(This,mu,sigma)	\
    (This)->lpVtbl -> SetParamsGaussian(This,mu,sigma)

#define IImageGenerator_SetParamsCheckerCircle(This,angle,radius_inner,radius_outer,rings,slices,background)	\
    (This)->lpVtbl -> SetParamsCheckerCircle(This,angle,radius_inner,radius_outer,rings,slices,background)

#define IImageGenerator_SetParamsEllipse(This,width,height,angle)	\
    (This)->lpVtbl -> SetParamsEllipse(This,width,height,angle)

#define IImageGenerator_SetParamsAnnulus(This,inner_width,inner_height,outer_width,outer_height,angle)	\
    (This)->lpVtbl -> SetParamsAnnulus(This,inner_width,inner_height,outer_width,outer_height,angle)

#define IImageGenerator_GetSize(This,width,height)	\
    (This)->lpVtbl -> GetSize(This,width,height)

#define IImageGenerator_SetOffset(This,offset_x,offset_y)	\
    (This)->lpVtbl -> SetOffset(This,offset_x,offset_y)

#define IImageGenerator_SetForeground(This,foreground)	\
    (This)->lpVtbl -> SetForeground(This,foreground)

#define IImageGenerator_SetBackground(This,background)	\
    (This)->lpVtbl -> SetBackground(This,background)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetType_Proxy( 
    IImageGenerator * This,
    /* [in] */ ULONG type);


void __RPC_STUB IImageGenerator_SetType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_Generate_Proxy( 
    IImageGenerator * This,
    /* [in] */ ULONG width,
    /* [in] */ ULONG height);


void __RPC_STUB IImageGenerator_Generate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_Multiply_Proxy( 
    IImageGenerator * This);


void __RPC_STUB IImageGenerator_Multiply_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_Mask1_Proxy( 
    IImageGenerator * This);


void __RPC_STUB IImageGenerator_Mask1_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_Mask2_Proxy( 
    IImageGenerator * This);


void __RPC_STUB IImageGenerator_Mask2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_Sum_Proxy( 
    IImageGenerator * This);


void __RPC_STUB IImageGenerator_Sum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_Min_Proxy( 
    IImageGenerator * This);


void __RPC_STUB IImageGenerator_Min_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_Max_Proxy( 
    IImageGenerator * This);


void __RPC_STUB IImageGenerator_Max_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_GenerateBitmap_Proxy( 
    IImageGenerator * This,
    /* [out] */ BYTE *buffer,
    /* [in] */ ULONG bpp,
    /* [in] */ ULONG pitch,
    /* [in] */ DOUBLE redBackground,
    /* [in] */ DOUBLE redAmplitude,
    /* [in] */ DOUBLE greenBackground,
    /* [in] */ DOUBLE greenAmplitude,
    /* [in] */ DOUBLE blueBackground,
    /* [in] */ DOUBLE blueAmplitude);


void __RPC_STUB IImageGenerator_GenerateBitmap_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetParamsGradient_Proxy( 
    IImageGenerator * This,
    /* [in] */ DOUBLE angle,
    /* [in] */ DOUBLE period,
    /* [in] */ DOUBLE phase,
    /* [in] */ SHORT square);


void __RPC_STUB IImageGenerator_SetParamsGradient_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetParamsRadial_Proxy( 
    IImageGenerator * This,
    /* [in] */ DOUBLE sfreq,
    /* [in] */ DOUBLE phase,
    /* [in] */ SHORT square);


void __RPC_STUB IImageGenerator_SetParamsRadial_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetParamsCircular_Proxy( 
    IImageGenerator * This,
    /* [in] */ DOUBLE period,
    /* [in] */ DOUBLE phase,
    /* [in] */ SHORT square);


void __RPC_STUB IImageGenerator_SetParamsCircular_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetParamsGaussian_Proxy( 
    IImageGenerator * This,
    /* [in] */ DOUBLE mu,
    /* [in] */ DOUBLE sigma);


void __RPC_STUB IImageGenerator_SetParamsGaussian_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetParamsCheckerCircle_Proxy( 
    IImageGenerator * This,
    /* [in] */ DOUBLE angle,
    /* [in] */ DOUBLE radius_inner,
    /* [in] */ DOUBLE radius_outer,
    /* [in] */ ULONG rings,
    /* [in] */ ULONG slices,
    /* [in] */ DOUBLE background);


void __RPC_STUB IImageGenerator_SetParamsCheckerCircle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetParamsEllipse_Proxy( 
    IImageGenerator * This,
    /* [in] */ DOUBLE width,
    /* [in] */ DOUBLE height,
    /* [in] */ DOUBLE angle);


void __RPC_STUB IImageGenerator_SetParamsEllipse_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetParamsAnnulus_Proxy( 
    IImageGenerator * This,
    /* [in] */ DOUBLE inner_width,
    /* [in] */ DOUBLE inner_height,
    /* [in] */ DOUBLE outer_width,
    /* [in] */ DOUBLE outer_height,
    /* [in] */ DOUBLE angle);


void __RPC_STUB IImageGenerator_SetParamsAnnulus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_GetSize_Proxy( 
    IImageGenerator * This,
    /* [out] */ ULONG *width,
    /* [out] */ ULONG *height);


void __RPC_STUB IImageGenerator_GetSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetOffset_Proxy( 
    IImageGenerator * This,
    /* [in] */ DOUBLE offset_x,
    /* [in] */ DOUBLE offset_y);


void __RPC_STUB IImageGenerator_SetOffset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetForeground_Proxy( 
    IImageGenerator * This,
    /* [in] */ DOUBLE foreground);


void __RPC_STUB IImageGenerator_SetForeground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IImageGenerator_SetBackground_Proxy( 
    IImageGenerator * This,
    /* [in] */ DOUBLE background);


void __RPC_STUB IImageGenerator_SetBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IImageGenerator_INTERFACE_DEFINED__ */



#ifndef __ReferenceImageGeneratorLib_LIBRARY_DEFINED__
#define __ReferenceImageGeneratorLib_LIBRARY_DEFINED__

/* library ReferenceImageGeneratorLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ReferenceImageGeneratorLib;

EXTERN_C const CLSID CLSID_ImageGenerator;

#ifdef __cplusplus

class DECLSPEC_UUID("8FA0728A-8A0F-45EC-8210-0FA30D784955")
ImageGenerator;
#endif
#endif /* __ReferenceImageGeneratorLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


