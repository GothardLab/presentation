#include "stdafx.h"
#include "normalized_graphic.h"
#include "exception.h"

using namespace nbs;

//---------------------------------------------------------------------------
//
// class Normalized_graphic
//
//--------------------------------------------------------------------------- 

void Normalized_graphic::construct_bitmap( Surface_data& s
										  , double red_background, double red_amplitude
										  , double green_background, double green_amplitude
										  , double blue_background, double blue_amplitude )
{
	if( s.width != width_ || s.height != height_ ) 
	{
		throw Exception( L"Normalized_graphic::construct_bitmap was passed Graphic_data with incorrect dimentions.  This is a bug." );
	}
	if( s.bit_count != 24 && s.bit_count != 32 ) 
	{
		throw Exception( L"Normalized_graphic::construct_bitmap was passed Graphic_data with incorrect bit depth.  This is a bug." );
	}
	if( s.width != 0 && s.height != 0 ) 
	{
		Data_type* source = buffer_.get();
		for (unsigned int row = 0; row < s.height; ++row)
		{
			uint8* dest = s.ptr + row * s.pitch;
			for (unsigned int col = 0; col < s.width; ++col)
			{
				// note: color order is bgr for bitmaps
				*dest = static_cast<uint8>( blue_background + blue_amplitude * *source + 0.5 );
				++dest;
				*dest = static_cast<uint8>( green_background + green_amplitude * *source + 0.5 );
				++dest;
				*dest = static_cast<uint8>( red_background + red_amplitude * *source + 0.5 );
				++dest;
				if (s.bit_count == 32)
				{
					*dest = 255;
					++dest;
				}
				++source;
			}
		}
	}
}

//--------------------------------------------------------------------------- 

template <class T>
void Normalized_graphic::transform( const Normalized_graphic& graphic )
{
	if( graphic.width() != width_ || graphic.height() != height_ ) 
	{
		throw Exception( L"Normalized_graphic::transform was passed Normalized_graphic with incorrect dimentions.  This is a bug." );
	}
	if( width_ != 0 && height_ != 0 ) 
	{
		const Data_type* s = graphic.buffer();
		Data_type* d = buffer_.get();
		Data_type* e = d + width_ * height_;
		for( ; d != e; ++d, ++s ) 
		{
			*d = T::transform( *d, *s );
		}
	}
}

//--------------------------------------------------------------------------- 

namespace {

struct Multiply
{
	static Normalized_graphic::Data_type transform( Normalized_graphic::Data_type v1, 
		Normalized_graphic::Data_type v2 )
	{
		return v1 * v2;
	}
};

struct Mask1
{
	static Normalized_graphic::Data_type transform( Normalized_graphic::Data_type v1, 
		Normalized_graphic::Data_type v2 )
	{
		return v1 * (v2 + 1) / 2;
	}
};

struct Mask2
{
	static Normalized_graphic::Data_type transform( Normalized_graphic::Data_type v1, 
		Normalized_graphic::Data_type v2 )
	{
		return v2 * (v1 + 1) / 2;
	}
};

struct Sum
{
	static Normalized_graphic::Data_type transform( Normalized_graphic::Data_type v1, 
		Normalized_graphic::Data_type v2 )
	{
		return v1 + v2;
	}
};

struct Minimum
{
	static Normalized_graphic::Data_type transform( Normalized_graphic::Data_type v1, 
		Normalized_graphic::Data_type v2 )
	{
		return v1 < v2 ? v1 : v2;
	}
};

struct Maximum
{
	static Normalized_graphic::Data_type transform( Normalized_graphic::Data_type v1, 
		Normalized_graphic::Data_type v2 )
	{
		return v1 > v2 ? v1 : v2;
	}
};

}

//--------------------------------------------------------------------------- 

void Normalized_graphic::multiply( const Normalized_graphic& graphic )
{
	transform<Multiply>( graphic );
}

//--------------------------------------------------------------------------- 

void Normalized_graphic::mask1( const Normalized_graphic& graphic )
{
	transform<Mask1>( graphic );
}

//--------------------------------------------------------------------------- 

void Normalized_graphic::mask2( const Normalized_graphic& graphic )
{
	transform<Mask2>( graphic );
}

//--------------------------------------------------------------------------- 

void Normalized_graphic::sum( const Normalized_graphic& graphic )
{
	transform<Sum>( graphic );
}

//--------------------------------------------------------------------------- 

void Normalized_graphic::minimum( const Normalized_graphic& graphic )
{
	transform<Minimum>( graphic );
}

//--------------------------------------------------------------------------- 

void Normalized_graphic::maximum( const Normalized_graphic& graphic )
{
	transform<Maximum>( graphic );
}

//--------------------------------------------------------------------------- 








